import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';
import {Audio} from 'expo-av';

class Sound1button extends React.Component{
 playSound = async () => {
   await Audio.Sound.createAsync(
     {
       uri: "http://soundbible.com/grab.php?id=1137&type=mp3"
     },
     {
       shouldPlay: true
     }
   )
 }
  
  render() {
    return(
      <View style= {{marginTop: 35}}>
      <Button title= "sound 1" color="lightblue" onPress={this.playSound}/>
      </View>
    )
  }
}

class Sound2button extends React.Component{
playSound = async () => {
  await Audio.Sound.createAsync(
    {
      uri: "http://soundbible.com/grab.php?id=1247&type=mp3"
    },
    {
      shouldPlay: true
    }
  )
}
  render(){
    return(
      <View style= {{marginTop:35}}>
      <Button title="sound 2" color="cyan"onPress={this.playSound}/>
      </View>
    )
  }
}

class Sound3button extends React.Component{
  playSound = async () => {
    await Audio.Sound.createAsync(
      {
        uri: "http://soundbible.com/grab.php?id=1444&type=mp3"
      },
      {
        shouldPlay: true
      }
    )
  }
  render(){
   return(
     <View style={{marginTop:35}}>
    <Button title="sound 3" color=""onPress={this.playSound}/>
    </View>
   )
  }
}

class Sound4button extends React.Component{
  playSound = async () => {
    await Audio.Sound.createAsync(
      {
        uri: "http://soundbible.com/grab.php?id=309&type=mp3"
      },
{
  shouldPlay: true 
}
    )
  }
  render(){
    return(
      <View style={{marginTop:35}}>
      <Button title="sound 4" color="blue"onPress={this.playSound}/>
      </View>
    )
  }
}

class Sound5button extends React.Component{
  playSound= async () =>{
    await Audio.Sound.createAsync(
      {
        uri: "http://soundbible.com/grab.php?id=105&type=mp3"
      },
      {
        shouldPlay : true
      }
    )
  }
  render(){
    return(
      <View style={{marginTop:35}}>
      <Button title="sound 5" color="darkblue"onPress={this.playSound}/>
    </View> 
    )
  }
} 


export default class App extends Component {
  render() {
    return (
      <View>
        <Text style={{marginTop:30, fontWeight: "bold",}}>Hello welcome to my DJ App, enjoy!</Text>
    <Sound1button/>
    <Sound2button/>
    <Sound3button/>
    <Sound4button/>
    <Sound5button/>
    </View>
    ); 
  }
}



